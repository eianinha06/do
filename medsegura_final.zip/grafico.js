const ctx = document.getElementById('graficoConsultas').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai'],
    datasets: [{
      label: 'Consultas por mês',
      data: [30, 45, 50, 40, 60],
      backgroundColor: '#00aa88'
    }]
  }
});
