function validarLogin(email, senha) {
  if (email === "" || senha === "") {
    alert("Preencha todos os campos!");
    return false;
  }
  alert("Login realizado!");
  return true;
}
